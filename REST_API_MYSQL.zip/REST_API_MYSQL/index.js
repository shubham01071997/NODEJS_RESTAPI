const express=require("express");
const mysql=require("mysql");
const app=express();
const port=8080;
app.use(express.json());
const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    port: 3306
})
db.connect((err)=>{
    if(!err){

        console.log("DB connected");
    }else{
        console.log(err);
        console.log("DB connected Fail");
    }
})

//add
app.post("/save",async (req,res)=>{
    try{
    const save=`INSERT INTO data.persons (LastName, FirstName, Age) VALUES ("${req.body.LastName}","${req.body.FirstName}","${req.body.Age}")`;
    const saveData=await db.query(save);
    if(saveData){
        res.status(200).json({message:"Data Save Succesfully"});
    }else{
        res.status(200).json({message:"Fail"});
    }
}catch(err){
    res.status(400).json({message:err});
}
});
//all
app.get("/getAllPerson",(req,res)=>{
    const q1=`select * from data.persons;`;
    
    db.query(q1,(err,resultData)=>{
        if(!err){
            res.status(200).json(resultData);
        }
    });
});

//find by id
app.get("/getPersonData/:id",(req,res)=>{
    const id=req.params.id;
    const q2=`select * from data.persons where id=${id};`;    
    db.query(q2,(err,resultData)=>{   
        res.status(200).json(resultData);
    });  
});

//delete
app.delete("/deletePersonData/:id",async (req,res)=>{ 
    try{
        const id=req.params.id;
        const q3=`delete from data.persons where id=${id};`;  
        const deleteData=await db.query(q3);
        if(deleteData){
            res.status(200).json({message:"Delete Data Succesfully"});
        }else{
            res.status(200).json({message:"Fail"});
        }
    }catch(err){
        res.status(400).json({message:err});
    }
});
//update
app.put("/update/:id",async (req,res)=>{
    const id=req.params.id;
    try{
    const update=`UPDATE data.persons SET LastName="${req.body.LastName}",FirstName="${req.body.FirstName}",Age="${req.body.Age}"  WHERE id =${id};`;
    const updateData=await db.query(update);
    if(updateData){
        res.status(200).json({message:"Data update Succesfully"});
    }else{
        res.status(200).json({message:"Fail"});
    }
}catch(err){
    res.status(400).json({message:err});
}
});

app.listen(port,()=>{
    console.log(`api runing ${port}`)
});